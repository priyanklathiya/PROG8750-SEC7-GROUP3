import React from 'react'

function ViewProduct() {
  return (
    <main>
      ViewProduct
    </main>
  )
}

export default ViewProduct
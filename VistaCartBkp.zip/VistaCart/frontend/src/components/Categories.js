import React from 'react'

function Categories() {
  return (
    <main>View All Categories</main>
  )
}

export default Categories
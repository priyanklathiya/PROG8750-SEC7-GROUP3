import React from 'react'

function AdminDashboard() {
  return (
    <main>AdminDashboard</main>
  )
}

export default AdminDashboard